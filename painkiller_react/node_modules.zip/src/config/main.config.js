/**
 * Created by Matijas on 11.04.2017.
 */
export default {
    BASE_URL: location.hostname === "localhost" ? 'https://jsonplaceholder.typicode.com/' : 'https://jsonplaceholder.typicode.com/'
}