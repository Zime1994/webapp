import { combineReducers } from "redux"

import welcomeText from "./welcomeTextReducer"

export default combineReducers({
  welcomeText
})