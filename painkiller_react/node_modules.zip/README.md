# How to start 

1. install `webpack` globally. run `npm i -g webpack`
2. change to your project directory
3. run `npm i`
4. run `webpack`
5. run `npm run dev`
6. open browser with `http://localhost:8080/`